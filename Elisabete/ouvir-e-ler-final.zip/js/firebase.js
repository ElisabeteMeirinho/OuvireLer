import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithPopup } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyDKRn1M5HvCRo9dtCWFP3adepUEe7lBbvg",
  authDomain: "ouvir-e-ler.firebaseapp.com",
  projectId: "ouvir-e-ler",
  storageBucket: "ouvir-e-ler.appspot.com",
  messagingSenderId: "1032722618943",
  appId: "1:1032722618943:web:21d05ad36b46290ca6b68a",
  measurementId: "G-V167H5ZQLV"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();

document.getElementById('entrarGmail').addEventListener('click', async () => {
  try {
    const result = await signInWithPopup(auth, provider);
    const user = result.user;
    document.getElementById('loginSection').style.display = 'none';
    document.getElementById('grupoSection').classList.remove('hidden');
    alert("Olá, " + user.displayName);
  } catch (error) {
    console.error("Erro ao logar:", error);
  }
});
