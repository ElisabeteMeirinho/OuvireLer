const startBtn = document.getElementById('startBtn');
const transcript = document.getElementById('transcript');

let recognition;

if ('webkitSpeechRecognition' in window) {
  recognition = new webkitSpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = 'pt-BR';

  startBtn.addEventListener('click', () => {
    transcript.classList.remove('hidden');
    recognition.start();
  });

  recognition.onresult = function(event) {
    let finalTranscript = '';
    for (let i = event.resultIndex; i < event.results.length; ++i) {
      finalTranscript += event.results[i][0].transcript;
    }
    transcript.textContent = finalTranscript;
  };
} else {
  startBtn.disabled = true;
  transcript.textContent = 'Este navegador não suporta reconhecimento de voz.';
}
