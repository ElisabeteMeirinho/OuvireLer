
function startRecognition() {
  const nome = document.getElementById("nome").value || "Anônimo";
  const mensagens = document.getElementById("mensagens");

  if (!('webkitSpeechRecognition' in window)) {
    alert("Seu navegador não suporta a Web Speech API.");
    return;
  }

  const recognition = new webkitSpeechRecognition();
  recognition.lang = "pt-BR";
  recognition.continuous = false;
  recognition.interimResults = false;

  recognition.onresult = function(event) {
    const resultado = event.results[0][0].transcript;
    const item = document.createElement("li");
    item.innerText = nome + ": " + resultado;
    mensagens.prepend(item);
  };

  recognition.start();
}
