
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-app.js";
import { getFirestore, collection, addDoc, onSnapshot } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-firestore.js";


const firebaseConfig = {
  apiKey: "AIzaSyDKRn1M5HvCRo9dtCWFP3adepUEe7lBbvg",
  authDomain: "ouvir-e-ler.firebaseapp.com",
  projectId: "ouvir-e-ler",
  storageBucket: "ouvir-e-ler.firebasestorage.app",
  messagingSenderId: "1032722618943",
  appId: "1:1032722618943:web:21d05ad36b46290ca6b68a",
  measurementId: "G-V167H5ZQLV"
};


// Inicializa Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

window.startRecognition = function() {
  const nome = document.getElementById("nome").value || "Anônimo";

  if (!('webkitSpeechRecognition' in window)) {
    alert("Seu navegador não suporta a Web Speech API.");
    return;
  }

  const recognition = new webkitSpeechRecognition();
  recognition.lang = "pt-BR";
  recognition.continuous = false;
  recognition.interimResults = false;

  recognition.onresult = async function(event) {
    const resultado = event.results[0][0].transcript;
    try {
      await addDoc(collection(db, "mensagens"), {
        nome: nome,
        texto: resultado,
        timestamp: new Date()
      });
    } catch (e) {
      console.error("Erro ao salvar fala:", e);
    }
  };

  recognition.start();
};

// Atualiza lista em tempo real
const mensagens = document.getElementById("mensagens");
onSnapshot(collection(db, "mensagens"), (snapshot) => {
  mensagens.innerHTML = "";
  snapshot.docs
    .sort((a, b) => b.data().timestamp?.seconds - a.data().timestamp?.seconds)
    .forEach(doc => {
      const data = doc.data();
      const item = document.createElement("li");
      item.innerText = data.nome + ": " + data.texto;
      mensagens.appendChild(item);
    });
});
